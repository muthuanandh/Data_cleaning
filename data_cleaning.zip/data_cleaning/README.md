# Data Cleaning & Visualization Using Python

A beginner-friendly Python project that takes a raw (synthetic) student performance dataset, cleans it with **Pandas**, explores it with **NumPy/Pandas**, and visualizes it with **Matplotlib** and **Seaborn**.

> **Note:** `students.csv` is a **synthetic sample dataset** generated with a fixed random seed. It contains no real student data. Duplicates, missing values and outliers were added on purpose to demonstrate data cleaning.

## Project Overview
Real-world data is rarely clean. This project builds a complete, reproducible pipeline: load raw data → inspect → clean → analyse → visualize → save results.

## Problem Statement
The raw student dataset has missing values, duplicate records and unrealistic or extreme values. Analysing it directly would give misleading averages and charts. The data must be cleaned and validated before analysis.

## Objectives
- Load and inspect a raw CSV dataset
- Handle missing values, duplicates and outliers
- Validate the cleaned data and save it as `cleaned_data.csv`
- Compute descriptive statistics and correlations from the actual data
- Produce clear charts and a combined dashboard

## Features
- Fully automatic: one command runs everything
- Generates the sample dataset reproducibly (seed = 42) if `students.csv` is missing
- Median imputation (numeric) and mode imputation / placeholder (categorical)
- Domain-limit checks (e.g. Marks must be 0–100) plus IQR outlier capping
- Friendly error messages for missing files or wrong columns
- Output folders are created automatically
- All statistics are calculated, never hardcoded

## Technology Stack
Python 3 · Pandas · NumPy · Matplotlib · Seaborn · CSV · Git & GitHub

## Dataset Description
| Column | Description |
|---|---|
| Student_ID | Unique identifier (never modified as a measurement) |
| Name | Student name (synthetic) |
| Age | Age in years |
| Gender | Male / Female |
| Department | CSE, ECE, EEE, MECH, CIVIL, IT |
| Attendance | Attendance percentage |
| Marks | Marks out of 100 |
| Study_Hours | Average study hours per day |

The raw file has 110 unique students plus 8 duplicate rows, deliberate missing values in every column except `Student_ID`, and several extreme/invalid values.

## Project Folder Structure
```
data_cleaning/
├── main.py                  # complete application
├── students.csv             # raw synthetic dataset
├── requirements.txt         # dependencies
├── README.md
├── GITHUB_GUIDE.md          # step-by-step publishing guide
├── .gitignore
├── cleaned_data.csv         # generated
├── analysis_summary.txt     # generated
└── visualizations/          # generated
    ├── department_marks.png
    ├── marks_distribution.png
    ├── marks_outliers.png
    ├── study_hours_vs_marks.png
    ├── gender_distribution.png
    ├── correlation_heatmap.png
    ├── department_attendance.png
    └── dashboard.png
```

## Data Cleaning Workflow
```mermaid
flowchart TD
    A[Load students.csv] --> B[Inspect: head, shape, columns, dtypes]
    B --> C[Count missing values]
    C --> D[Convert types and trim text]
    D --> E[Remove duplicate records]
    E --> F[Mark impossible values as missing]
    F --> G[Impute: median / mode / Unknown]
    G --> H[Detect outliers with IQR and cap them]
    H --> I[Validate: no missing, no duplicates]
    I --> J[Save cleaned_data.csv]
    J --> K[EDA summary + charts]
```

**Assumptions**
1. Exact duplicate rows are removed first, so copies are not imputed twice. Repeated `Student_ID`s are also dropped (first record kept).
2. Valid ranges: Age 15–50, Attendance 0–100, Marks 0–100, Study_Hours 0–24. Values outside are entry errors, so they are treated as missing and imputed.
3. Remaining extreme values are **capped** to the IQR bounds `[Q1 − 1.5·IQR, Q3 + 1.5·IQR]` instead of deleted, so valid records are preserved.
4. Only `Age`, `Attendance`, `Marks` and `Study_Hours` are treated as measurements; `Student_ID` is never altered.

## Visualizations Produced
| Chart | File |
|---|---|
| Average marks by department | `visualizations/department_marks.png` |
| Marks distribution | `visualizations/marks_distribution.png` |
| Marks before vs after outlier treatment | `visualizations/marks_outliers.png` |
| Study hours vs marks | `visualizations/study_hours_vs_marks.png` |
| Gender distribution | `visualizations/gender_distribution.png` |
| Correlation heatmap | `visualizations/correlation_heatmap.png` |
| Average attendance by department | `visualizations/department_attendance.png` |
| Combined dashboard | `visualizations/dashboard.png` |

### Dashboard
![Dashboard](visualizations/dashboard.png)

### Department-wise Average Marks
![Department Marks](visualizations/department_marks.png)

### Marks Distribution
![Marks Distribution](visualizations/marks_distribution.png)

### Marks Before vs After Outlier Treatment
![Marks Outliers](visualizations/marks_outliers.png)

### Study Hours vs Marks
![Study Hours vs Marks](visualizations/study_hours_vs_marks.png)

### Gender Distribution
![Gender Distribution](visualizations/gender_distribution.png)

### Correlation Heatmap
![Correlation Heatmap](visualizations/correlation_heatmap.png)

### Average Attendance by Department
![Department Attendance](visualizations/department_attendance.png)

## Installation Instructions
1. Install Python 3.9+ from python.org (tick *Add Python to PATH* on Windows).
2. Open a terminal in the project folder (`data_cleaning`).
3. (Optional) create a virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate        # Windows
   source venv/bin/activate     # Mac / Linux
   ```
4. Install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Execution Instructions
From the project root folder:
```bash
python main.py
```
(use `python3 main.py` on Mac/Linux). The program prints the data overview, cleaning validation and analysis, then saves all outputs.

## Expected Outputs
- `cleaned_data.csv` – the cleaned dataset
- `analysis_summary.txt` – all statistics calculated from the data
- `visualizations/*.png` – 7 charts + `dashboard.png`

## Key Learning Outcomes
- Loading and inspecting data with Pandas
- Handling missing values, duplicates and outliers (IQR)
- Using domain knowledge to validate data
- Writing readable, reusable functions with `pathlib`
- Creating Matplotlib/Seaborn charts and dashboards
- Publishing a project on GitHub

## Limitations
- The dataset is synthetic, so findings do not describe real students
- Capping and median imputation reduce variance and can hide real extremes
- Only simple, beginner-level techniques are used (no machine learning)

## Future Enhancements
- Accept any CSV via command-line arguments
- Add unit tests and a Jupyter notebook version
- Build an interactive dashboard (Streamlit or Plotly)
- Compare imputation strategies (mean, KNN)
- Add grade categories and a simple prediction model

## Author
**Muthu Anandh S**
