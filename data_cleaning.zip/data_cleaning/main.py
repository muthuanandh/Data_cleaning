"""
Data Cleaning & Visualization Using Python
==========================================
Author : Muthu Anandh S

What this script does (run it from the project root: python main.py):
  1. Creates the SYNTHETIC sample dataset students.csv (only if it is missing)
  2. Loads and inspects the raw data
  3. Cleans it (duplicates, invalid values, missing values, outliers)
  4. Runs exploratory data analysis (EDA) - every number is calculated
  5. Saves cleaned_data.csv, analysis_summary.txt and charts in visualizations/

NOTE: students.csv is artificially generated with a fixed random seed.
      It does NOT contain real student information.
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # save charts to files without opening windows
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# ----------------------------------------------------------------------
# Paths (pathlib keeps them portable across Windows / Mac / Linux)
# ----------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
RAW_FILE = BASE_DIR / "students.csv"
CLEAN_FILE = BASE_DIR / "cleaned_data.csv"
SUMMARY_FILE = BASE_DIR / "analysis_summary.txt"
VIS_DIR = BASE_DIR / "visualizations"

RANDOM_SEED = 42
NUMERIC_COLS = ["Age", "Attendance", "Marks", "Study_Hours"]   # measurements
CATEGORICAL_COLS = ["Name", "Gender", "Department"]
REQUIRED_COLS = ["Student_ID"] + CATEGORICAL_COLS + NUMERIC_COLS

# Sensible real-world limits. Values outside them are data-entry errors.
DOMAIN_LIMITS = {
    "Age": (15, 50),
    "Attendance": (0, 100),   # percentage
    "Marks": (0, 100),        # out of 100
    "Study_Hours": (0, 24),   # hours per day
}

sns.set_theme(style="whitegrid")


# ======================================================================
# STEP 1: Synthetic dataset generation
# ======================================================================
def generate_sample_dataset(path, seed=RANDOM_SEED):
    """Create a reproducible, SYNTHETIC student dataset with deliberate
    missing values, duplicate rows and outliers."""
    rng = np.random.default_rng(seed)
    n = 110

    first = ["Aarav", "Vivaan", "Aditya", "Arjun", "Karthik", "Rahul", "Suresh",
             "Vignesh", "Praveen", "Dinesh", "Priya", "Ananya", "Divya",
             "Kavya", "Meena", "Nandhini", "Sanjana", "Harini", "Lakshmi",
             "Deepa", "Gokul", "Naveen", "Ramya", "Swetha"]
    last = ["Kumar", "Raj", "Sharma", "Iyer", "Nair", "Reddy", "Pillai",
            "Murugan", "Selvam", "Krishnan", "Babu"]

    # Unique names built from first + last name combinations
    combos = [f"{f} {l}" for f in first for l in last]
    names = rng.choice(combos, size=n, replace=False)

    departments = rng.choice(["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT"],
                             size=n, p=[0.25, 0.18, 0.15, 0.15, 0.12, 0.15])
    gender = rng.choice(["Male", "Female"], size=n, p=[0.55, 0.45])
    age = rng.choice([18, 19, 20, 21, 22, 23], size=n,
                     p=[0.15, 0.25, 0.25, 0.2, 0.1, 0.05]).astype(float)
    study = np.clip(rng.normal(3.5, 1.4, n), 0.5, 8).round(1)
    attendance = np.clip(rng.normal(80, 9, n), 50, 100).round(1)
    # Marks depend (loosely) on study hours and attendance, plus random noise
    marks = np.clip(20 + 5.5 * study + 0.3 * attendance
                    + rng.normal(0, 7, n), 15, 100).round(1)

    df = pd.DataFrame({
        "Student_ID": [f"S{i:03d}" for i in range(1, n + 1)],
        "Name": names, "Age": age, "Gender": gender,
        "Department": departments, "Attendance": attendance,
        "Marks": marks, "Study_Hours": study,
    })

    # --- Inject outliers / invalid entries ---
    df.loc[7, "Marks"] = 250.0        # impossible (typing error)
    df.loc[23, "Marks"] = 4.0         # extreme low score
    df.loc[41, "Marks"] = -12.0       # impossible negative marks
    df.loc[58, "Study_Hours"] = 18.5  # unrealistic but possible
    df.loc[75, "Study_Hours"] = 30.0  # impossible (> 24 hours)
    df.loc[90, "Attendance"] = 12.0   # extreme low attendance
    df.loc[15, "Age"] = 35.0          # mature-student outlier
    df.loc[66, "Age"] = 3.0           # impossible age

    # --- Inject missing values ---
    for col, count in [("Age", 5), ("Gender", 4), ("Department", 4),
                       ("Attendance", 6), ("Marks", 6), ("Study_Hours", 5),
                       ("Name", 3)]:
        rows = rng.choice(df.index, size=count, replace=False)
        df[col] = df[col].astype(object)
        df.loc[rows, col] = np.nan

    # Store ages as whole numbers (nullable integer) so the CSV shows 21, not 21.0
    df["Age"] = pd.to_numeric(df["Age"]).astype("Int64")

    # --- Inject duplicate records (exact copies placed next to the original) ---
    dup_rows = rng.choice(df.index, size=8, replace=False)
    dups = df.loc[dup_rows].copy()
    dups.index = dups.index + 0.5
    df = pd.concat([df, dups]).sort_index().reset_index(drop=True)

    df.to_csv(path, index=False)
    print(f"Synthetic dataset created: {path.name} ({len(df)} rows)")


# ======================================================================
# STEP 2: Load and inspect
# ======================================================================
def load_data(path):
    """Load the CSV file; exit with a friendly message if something is wrong."""
    if not path.exists():
        print(f"ERROR: input file not found: {path}")
        sys.exit(1)
    try:
        df = pd.read_csv(path)
    except Exception as err:  # unreadable or malformed file
        print(f"ERROR: could not read {path.name}: {err}")
        sys.exit(1)
    if df.empty:
        print("ERROR: the dataset is empty.")
        sys.exit(1)
    missing_cols = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing_cols:
        print(f"ERROR: required columns missing: {missing_cols}")
        sys.exit(1)
    return df


def inspect_data(df):
    """Print first five rows, shape, column names and data types."""
    print("\n" + "=" * 60 + "\nRAW DATA OVERVIEW\n" + "=" * 60)
    print("First 5 rows:\n", df.head().to_string())
    print("\nShape (rows, columns):", df.shape)
    print("Columns:", list(df.columns))
    print("\nData types:\n", df.dtypes.to_string())


# ======================================================================
# STEP 3: Cleaning functions
# ======================================================================
def convert_types(df):
    """Make numeric columns truly numeric; unreadable text becomes NaN."""
    df = df.copy()
    for col in NUMERIC_COLS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in CATEGORICAL_COLS:
        df[col] = df[col].astype("string").str.strip()
    return df


def remove_duplicates(df):
    """Drop exact duplicate rows, then repeated Student_IDs (keep first)."""
    before = len(df)
    df = df.drop_duplicates()
    df = df.drop_duplicates(subset="Student_ID", keep="first")
    return df.reset_index(drop=True), before - len(df)


def mark_invalid_values(df):
    """Values outside realistic limits (e.g. Marks = 250) are errors, not
    genuine extremes, so they are set to NaN and imputed later."""
    df = df.copy()
    invalid = {}
    for col, (low, high) in DOMAIN_LIMITS.items():
        bad = (df[col] < low) | (df[col] > high)
        invalid[col] = int(bad.sum())
        df.loc[bad, col] = np.nan
    return df, invalid


def impute_missing(df):
    """Numeric -> median.  Name -> 'Unknown'.  Gender/Department -> mode."""
    df = df.copy()
    for col in NUMERIC_COLS:
        df[col] = df[col].fillna(df[col].median())
    df["Age"] = df["Age"].round().astype(int)  # ages are whole numbers
    df["Name"] = df["Name"].fillna("Unknown")
    for col in ["Gender", "Department"]:
        df[col] = df[col].fillna(df[col].mode()[0])
    return df


def iqr_bounds(series):
    """Return (lower, upper) bounds using the IQR rule."""
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    return q1 - 1.5 * iqr, q3 + 1.5 * iqr


def cap_outliers(df):
    """Detect outliers with IQR and cap (winsorize) them at the bounds.
    Student_ID is an identifier, so it is never touched."""
    df = df.copy()
    report = {}
    for col in NUMERIC_COLS:
        low, high = iqr_bounds(df[col])
        n_out = int(((df[col] < low) | (df[col] > high)).sum())
        report[col] = {"lower": low, "upper": high, "outliers": n_out}
        df[col] = df[col].clip(low, high)
    df["Age"] = df["Age"].round().astype(int)
    for col in ["Attendance", "Marks", "Study_Hours"]:
        df[col] = df[col].round(1)
    return df, report


def validate_clean(df):
    """Confirm there are no missing values or duplicates left."""
    return int(df.isnull().sum().sum()), int(df.duplicated().sum())


# ======================================================================
# STEP 4: Exploratory data analysis
# ======================================================================
def build_summary(raw, clean, dup_removed, invalid, outlier_report):
    """Create the analysis text. Everything is calculated from the data."""
    miss_before = raw.isnull().sum()
    miss_after = clean.isnull().sum()
    marks = clean["Marks"]
    dept_count = clean["Department"].value_counts()
    dept_marks = clean.groupby("Department")["Marks"].mean().round(2)
    corr = clean[NUMERIC_COLS].corr().round(3)

    lines = []
    add = lines.append
    add("ANALYSIS SUMMARY  (synthetic sample dataset)")
    add("=" * 60)
    add(f"Total records in raw data     : {len(raw)}")
    add(f"Duplicate records removed     : {dup_removed}")
    add(f"Total records after cleaning  : {len(clean)}")
    add("\nMissing values per column (before -> after cleaning):")
    for col in raw.columns:
        add(f"  {col:<12}: {int(miss_before[col])} -> {int(miss_after[col])}")
    add("\nInvalid values outside realistic limits (set to missing, imputed):")
    for col, n in invalid.items():
        low, high = DOMAIN_LIMITS[col]
        add(f"  {col:<12}: {n}  (valid range {low} to {high})")
    add("\nIQR outlier detection (capped at bounds):")
    for col, r in outlier_report.items():
        add(f"  {col:<12}: {r['outliers']} outlier(s), "
            f"bounds [{r['lower']:.2f}, {r['upper']:.2f}]")
    add("\nMarks statistics (after cleaning):")
    add(f"  Mean   : {marks.mean():.2f}")
    add(f"  Median : {marks.median():.2f}")
    add(f"  Minimum: {marks.min():.2f}")
    add(f"  Maximum: {marks.max():.2f}")
    add(f"\nAverage attendance  : {clean['Attendance'].mean():.2f} %")
    add(f"Average study hours : {clean['Study_Hours'].mean():.2f} hours/day")
    add("\nDepartment-wise student count:")
    for dept, cnt in dept_count.items():
        add(f"  {dept:<8}: {cnt}")
    add("\nDepartment-wise average marks:")
    for dept, avg in dept_marks.sort_values(ascending=False).items():
        add(f"  {dept:<8}: {avg}")
    add("\nCorrelation matrix:")
    add(corr.to_string())
    return "\n".join(lines)


# ======================================================================
# STEP 5: Visualizations
# ======================================================================
def plot_dept_marks(ax, clean):
    data = clean.groupby("Department")["Marks"].mean().sort_values(ascending=False)
    sns.barplot(x=data.index, y=data.values, hue=data.index, palette="viridis",
                legend=False, ax=ax)
    ax.set_title("Average Marks by Department")
    ax.set_xlabel("Department")
    ax.set_ylabel("Average Marks")
    for i, v in enumerate(data.values):
        ax.text(i, v + 0.5, f"{v:.1f}", ha="center", fontsize=8)


def plot_marks_hist(ax, clean):
    sns.histplot(clean["Marks"], bins=15, kde=True, color="steelblue", ax=ax)
    ax.axvline(clean["Marks"].mean(), color="red", linestyle="--",
               label=f"Mean = {clean['Marks'].mean():.1f}")
    ax.set_title("Distribution of Student Marks")
    ax.set_xlabel("Marks")
    ax.set_ylabel("Number of Students")
    ax.legend()


def plot_marks_boxplot(ax, raw_marks, clean_marks):
    box_df = pd.concat([
        pd.DataFrame({"Marks": raw_marks.dropna(), "Stage": "Before treatment"}),
        pd.DataFrame({"Marks": clean_marks, "Stage": "After treatment"}),
    ])
    sns.boxplot(data=box_df, x="Stage", y="Marks", hue="Stage",
                palette=["#e07a5f", "#81b29a"], legend=False, ax=ax)
    ax.set_title("Marks Before vs After Outlier Treatment")
    ax.set_xlabel("Stage")
    ax.set_ylabel("Marks")


def plot_scatter(ax, clean):
    sns.scatterplot(data=clean, x="Study_Hours", y="Marks", hue="Department",
                    alpha=0.8, ax=ax)
    sns.regplot(data=clean, x="Study_Hours", y="Marks", scatter=False,
                color="black", line_kws={"linestyle": "--", "label": "Trend line"},
                ax=ax)
    ax.set_title("Study Hours vs Marks")
    ax.set_xlabel("Study Hours (per day)")
    ax.set_ylabel("Marks")
    ax.legend(fontsize=7, title="Department")


def plot_gender(ax, clean):
    counts = clean["Gender"].value_counts()
    ax.pie(counts.values, labels=counts.index, autopct="%1.1f%%", startangle=90,
           colors=["#4c72b0", "#dd8452", "#55a868"][:len(counts)])
    ax.set_title("Gender Distribution")


def plot_heatmap(ax, clean):
    sns.heatmap(clean[NUMERIC_COLS].corr(), annot=True, fmt=".2f",
                cmap="coolwarm", vmin=-1, vmax=1, ax=ax)
    ax.set_title("Correlation Heatmap")


def plot_dept_attendance(ax, clean):
    data = clean.groupby("Department")["Attendance"].mean().sort_values(ascending=False)
    sns.barplot(x=data.index, y=data.values, hue=data.index, palette="mako",
                legend=False, ax=ax)
    ax.set_title("Average Attendance by Department")
    ax.set_xlabel("Department")
    ax.set_ylabel("Average Attendance (%)")
    for i, v in enumerate(data.values):
        ax.text(i, v + 0.5, f"{v:.1f}", ha="center", fontsize=8)


def save_single(plot_func, filename, *args, size=(8, 5)):
    """Draw one chart on its own figure and save it as PNG."""
    fig, ax = plt.subplots(figsize=size)
    plot_func(ax, *args)
    fig.tight_layout()
    fig.savefig(VIS_DIR / filename, dpi=150)
    plt.close(fig)


def create_visualizations(raw, clean):
    """Save the 7 charts plus a combined dashboard."""
    VIS_DIR.mkdir(parents=True, exist_ok=True)
    raw_marks = pd.to_numeric(raw["Marks"], errors="coerce")

    save_single(plot_dept_marks, "department_marks.png", clean)
    save_single(plot_marks_hist, "marks_distribution.png", clean)
    save_single(plot_marks_boxplot, "marks_outliers.png", raw_marks, clean["Marks"])
    save_single(plot_scatter, "study_hours_vs_marks.png", clean)
    save_single(plot_gender, "gender_distribution.png", clean, size=(6, 6))
    save_single(plot_heatmap, "correlation_heatmap.png", clean, size=(7, 6))
    save_single(plot_dept_attendance, "department_attendance.png", clean)

    # Combined dashboard (2 rows x 3 columns)
    fig, axes = plt.subplots(2, 3, figsize=(20, 11))
    plot_dept_marks(axes[0, 0], clean)
    plot_marks_hist(axes[0, 1], clean)
    plot_scatter(axes[0, 2], clean)
    plot_gender(axes[1, 0], clean)
    plot_heatmap(axes[1, 1], clean)
    plot_dept_attendance(axes[1, 2], clean)
    fig.suptitle("Student Performance Dashboard (Synthetic Data)",
                 fontsize=18, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(VIS_DIR / "dashboard.png", dpi=120)
    plt.close(fig)


# ======================================================================
# MAIN
# ======================================================================
def main():
    # Create the sample dataset on the first run
    if not RAW_FILE.exists():
        generate_sample_dataset(RAW_FILE)

    raw = load_data(RAW_FILE)
    inspect_data(raw)

    print("\nMissing values per column (raw):\n", raw.isnull().sum().to_string())

    # Cleaning pipeline
    df = convert_types(raw)
    df, dup_removed = remove_duplicates(df)
    df, invalid = mark_invalid_values(df)
    df = impute_missing(df)
    clean, outlier_report = cap_outliers(df)

    # Validation
    remaining_missing, remaining_dups = validate_clean(clean)
    print(f"\nValidation -> missing values left: {remaining_missing}, "
          f"duplicates left: {remaining_dups}")
    if remaining_missing or remaining_dups:
        print("ERROR: cleaning validation failed.")
        sys.exit(1)

    # Save outputs
    clean.to_csv(CLEAN_FILE, index=False)
    summary = build_summary(raw, clean, dup_removed, invalid, outlier_report)
    SUMMARY_FILE.write_text(summary, encoding="utf-8")
    print("\n" + summary)

    create_visualizations(raw, clean)
    print(f"\nDone! Saved: {CLEAN_FILE.name}, {SUMMARY_FILE.name}, "
          f"and charts in {VIS_DIR.name}/")


if __name__ == "__main__":
    main()
