# GitHub Publishing Guide

Repository name to use: **data-cleaning-visualization**
(Your local folder is `data_cleaning`; the GitHub repository name can differ.)

## Which files go to GitHub?
**Commit everything in the project folder:**
`main.py`, `students.csv`, `requirements.txt`, `README.md`, `GITHUB_GUIDE.md`, `.gitignore`, `cleaned_data.csv`, `analysis_summary.txt`, and the whole `visualizations/` folder.

Why include the generated files? The README displays the charts, so the PNGs must be in the repository. Visitors can also see the results without running anything.

**Ignored (see `.gitignore`):** `__pycache__/`, `venv/`, `.vscode/`, `.idea/`, `.DS_Store`, `Thumbs.db`. These are machine-specific or auto-created and add clutter.
The charts, CSVs and summary are deliberately *not* ignored.

## Method A: Upload through the website
1. Sign in at github.com (create a free account if needed).
2. Click **+** (top right) → **New repository**.
3. Repository name: `data-cleaning-visualization`. Choose **Public**. Do NOT tick "Add a README" (you already have one). Click **Create repository**.
4. Click **uploading an existing file**.
5. Open your `data_cleaning` folder, select ALL files and the `visualizations` folder, then drag them into the browser window. (`.gitignore` is a hidden file on some systems; if you don't see it, skip it or use Method B.)
6. Wait for uploads to finish, write the commit message `Initial commit: Data cleaning and visualization project`, and click **Commit changes**.
7. Open the repository page and check that the README shows the images.

## Method B: Git commands
1. Install Git from git-scm.com and check with `git --version`.
2. One-time setup (use your own details):
   ```bash
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```
3. Create the empty repository on GitHub as in Method A steps 2-3.
4. In a terminal, go into the project folder, e.g. on Windows `cd Desktop\data_cleaning`, then run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Data cleaning and visualization project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/data-cleaning-visualization.git
   git push -u origin main
   ```
5. **Replace `YOUR-USERNAME`** with your GitHub username (shown in your profile URL: github.com/**username**).
6. When asked to sign in, use the browser sign-in or GitHub Desktop / Git Credential Manager. GitHub no longer accepts account passwords for pushes; if you use a personal access token, type it only into the prompt. Never put passwords or tokens in code or files.

### Common problems
- **"remote origin already exists"** → fix the link:
  `git remote set-url origin https://github.com/YOUR-USERNAME/data-cleaning-visualization.git`
- **"Updates were rejected" / repository not empty** (you ticked "Add a README"): run
  `git pull origin main --allow-unrelated-histories`, resolve any conflict, then `git push -u origin main`.
- **"not a git repository"** → you are in the wrong folder or skipped `git init`.
- Check status any time with `git status` and `git remote -v`.

## Making the repository professional
**Description:** Python project that cleans a synthetic student dataset with Pandas and visualizes it using Matplotlib and Seaborn.

**Topics:** `python` `pandas` `numpy` `matplotlib` `seaborn` `data-cleaning` `data-visualization` `exploratory-data-analysis` `data-analysis` `student-project`

**README introduction (already at the top of README.md):** A beginner-friendly Python project that takes a raw (synthetic) student performance dataset, cleans it with Pandas, explores it, and visualizes it with Matplotlib and Seaborn.

(Add the description and topics via the ⚙ gear icon next to **About** on the repository page.)

## Final checklist
- [ ] `python main.py` runs without errors on your computer
- [ ] `cleaned_data.csv`, `analysis_summary.txt` and 8 PNGs exist
- [ ] Repository is **Public** and named `data-cleaning-visualization`
- [ ] README images display on GitHub
- [ ] Mermaid diagram renders
- [ ] `visualizations/` folder and PNGs are present
- [ ] No passwords, tokens or personal data in any file
- [ ] Description and topics added
- [ ] Author name appears in the README
- [ ] Opened the repo in a private/incognito window to confirm it is visible

## Resume description
**Data Cleaning & Visualization Using Python** – Built a Python project that cleans a synthetic student-performance dataset, performs exploratory data analysis and generates charts and a dashboard using Pandas, NumPy, Matplotlib and Seaborn. Published on GitHub with documentation.

**Bullets**
- Developed a Python pipeline using Pandas and NumPy to handle missing values, duplicate records and IQR-based outliers in a synthetic student dataset.
- Created seven Matplotlib/Seaborn visualizations and a combined dashboard to explore marks, attendance, study hours and department-wise trends.
- Documented and published the project on GitHub with a README, workflow diagram, reproducible sample data and dependency file.
